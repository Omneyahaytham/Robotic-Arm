Example files for Mathworks Robotics System Toolbox

Some of these are described in
P. Corke, "Integrating ROS and MATLAB [ROS Topics]," in IEEE Robotics & Automation Magazine, vol. 22, no. 2, pp. 18-20, June 2015.
doi: 10.1109/MRA.2015.2418513
